Universal TV v0.2.0
Created by noviciususor

Includes the two user-supplied M3U playlists, bundled locally with their original group-title categories.
Country -> Original category -> Channel -> Play.

To add a country, place its M3U in resources/data/ and add an entry in countries.json.
Kodi 19+ (Python 3). No remote playlist fetching; live channel streams require internet.
Playback, rights, and regional availability are not guaranteed.
