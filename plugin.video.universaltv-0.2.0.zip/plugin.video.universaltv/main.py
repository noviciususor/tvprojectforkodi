# -*- coding: utf-8 -*-
# Universal TV - Created by noviciususor
import sys, json, os, re, urllib.parse
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
DATA_DIR = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('path')), 'resources', 'data')

def link(**kwargs):
    return BASE + '?' + urllib.parse.urlencode(kwargs)

def countries():
    with open(os.path.join(DATA_DIR, 'countries.json'), encoding='utf-8') as f:
        return json.load(f)

def parse_m3u(path):
    with open(path, encoding='utf-8-sig', errors='replace') as f:
        lines = f.read().splitlines()
    channels = []
    pending = None
    current_group = 'Χωρίς κατηγορία / Uncategorized'
    for raw in lines:
        line = raw.strip()
        if line.startswith('#EXTGRP:'):
            current_group = line[len('#EXTGRP:'):].strip() or current_group
        elif line.startswith('#EXTINF:'):
            attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', line))
            title = line.split(',', 1)[1].strip() if ',' in line else attrs.get('tvg-name', 'Unknown')
            group = attrs.get('group-title') or current_group
            pending = {'title': title, 'group': group, 'logo': attrs.get('tvg-logo', '')}
        elif line and not line.startswith('#') and pending:
            if urllib.parse.urlparse(line).scheme.lower() in ('http', 'https'):
                pending['stream'] = line
                channels.append(pending)
            pending = None
    return channels

def add_folder(label, **params):
    item = xbmcgui.ListItem(label=label)
    item.setArt({'icon':'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(HANDLE, link(**params), item, True)

def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))
    action = params.get('action', '')
    if action == 'play':
        code = params.get('country', '')
        try:
            index = int(params.get('index', '-1'))
            country = next(c for c in countries() if c['code'] == code)
            channels = parse_m3u(os.path.join(DATA_DIR, country['playlist']))
            channel = channels[index] if 0 <= index < len(channels) else None
        except (ValueError, StopIteration, OSError, KeyError, IndexError):
            channel = None
        if not channel:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        item = xbmcgui.ListItem(path=channel['stream'])
        item.setInfo('video', {'title':channel['title'], 'mediatype':'video'})
        if channel['logo']:
            item.setArt({'thumb':channel['logo'], 'icon':channel['logo']})
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
        return
    if action in ('groups', 'channels'):
        country = next((c for c in countries() if c['code'] == params.get('country')), None)
        if not country:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        channels = parse_m3u(os.path.join(DATA_DIR, country['playlist']))
        if action == 'groups':
            for group in dict.fromkeys(c['group'] for c in channels):
                add_folder(group, action='channels', country=country['code'], group=group)
        else:
            group = params.get('group', '')
            for index, channel in enumerate(channels):
                if channel['group'] != group:
                    continue
                item = xbmcgui.ListItem(label=channel['title'])
                item.setProperty('IsPlayable', 'true')
                item.setInfo('video', {'title':channel['title'], 'mediatype':'video'})
                if channel['logo']:
                    item.setArt({'thumb':channel['logo'], 'icon':channel['logo']})
                xbmcplugin.addDirectoryItem(HANDLE, link(action='play', country=country['code'], index=index), item, False)
            xbmcplugin.setContent(HANDLE, 'videos')
    else:
        for country in countries():
            add_folder(country['name'], action='groups', country=country['code'])
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    main()
